function editData(button) { 
    // Get the parent row of the clicked button 
    let row = button.parentNode.parentNode; 
    
    // Get the cells within the row 
    let eventNameCell = row.cells[0]; 
    let eventLocationCell = row.cells[1]; 
    let eventDateTimeCell = row.cells[2]; 
    let eventQuantityCell = row.cells[3]; 
    let eventCostCell = row.cells[4]; 
    
    // Get the input fields within the cells 
    let eventNameInput = eventNameCell.querySelector('.edit-event-name'); 
    let eventLocationInput = eventLocationCell.querySelector('.edit-event-location'); 
    let eventDateTimeInput = eventDateTimeCell.querySelector('.edit-event-date-time'); 
    let eventQuantityInput = eventQuantityCell.querySelector('.edit-event-quantity'); 
    let eventCostInput = eventCostCell.querySelector('.edit-event-cost'); 
    
    // Populate the input fields with the current values
    // This way, the user can maintain current details if they would like
    eventNameInput.value = eventNameCell.querySelector('.event-name').textContent; 
    eventLocationInput.value = eventLocationCell.querySelector('.event-location').textContent; 
    eventDateTimeInput.value = eventDateTimeCell.querySelector('.event-date-time').textContent; 
    eventQuantityInput.value = eventQuantityCell.querySelector('.ticket-quantity').textContent; 
    eventCostInput.value = eventCostCell.querySelector('.ticket-cost').textContent; 
    
    // Prompt the user to enter updated values 
    let eventName = 
        prompt("Enter the updated event name or press OK to leave it the same:", 
            eventNameInput.value); 
    let eventLocation = 
        prompt("Enter the updated event location or press OK to leave it the same:", 
            eventLocationInput.value); 
    let eventDateTime = 
        prompt("Enter the updated event date and time (YYYY-MM-DD HH:MM) or press OK to leave it the same:", 
            eventDateTimeInput.value); 
    let eventQuantity = 
        prompt("Enter the updated quantity or press OK to leave it the same:", 
            eventQuantityInput.value); 
    let eventCost = 
        prompt("Enter the updated cost or press OK to leave it the same:", 
            eventCostInput.value); 
    
    // Update the cell contents with the new values 
    eventNameCell.querySelector('.event-name').textContent = eventName; 
    eventLocationCell.querySelector('.event-location').textContent = eventLocation; 
    eventDateTimeCell.querySelector('.event-date-time').textContent = eventDateTime; 
    eventQuantityCell.querySelector('.ticket-quantity').textContent = eventQuantity; 
    eventCostCell.querySelector('.ticket-cost').textContent = eventCost; 
}

function deleteData(button) { 
            
    // Get the parent row of the clicked button 
    let row = button.parentNode.parentNode; 

    // Remove the row from the table 
    row.parentNode.removeChild(row); 
} 
